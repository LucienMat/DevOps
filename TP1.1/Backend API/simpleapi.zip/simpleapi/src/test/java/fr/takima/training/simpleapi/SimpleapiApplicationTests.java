package fr.takima.training.simpleapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
